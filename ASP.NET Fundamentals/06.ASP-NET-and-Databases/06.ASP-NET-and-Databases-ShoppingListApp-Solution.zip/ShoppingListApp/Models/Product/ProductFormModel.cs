﻿namespace ShoppingListApp.Models.Product
{
    public class ProductFormModel
    {
        public string Name { get; set; } = null!;   
    }
}
